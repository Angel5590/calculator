

var greeting = "Hello, playground"

var Num1 = 9
var Num2 = 3
var mult = Num1 * Num2
var add = Num1 + Num2
var sub = Num1 - Num2
var div = Num1 / Num2

print("\(Num1) * \(Num2) = \(mult)")
print("\(Num1) + \(Num2) = \(add)")
print("\(Num1) - \(Num2) = \(sub)")
print("\(Num1) / \(Num2) = \(div)")

